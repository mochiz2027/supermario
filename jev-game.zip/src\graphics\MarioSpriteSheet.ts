/**
 * MarioSpriteSheet — 사용자가 제공한 고화질 픽셀 아트 마리오 스프라이트 렌더러
 * - 사전 이미지 로딩 및 캐싱
 * - 발바닥(지면) 및 중심축 기준 픽셀 퍼펙트 안착
 * - 도트 깨짐 방지 및 부드러운 스케일링
 */

import { drawSprite as drawProceduralSprite } from './ProceduralSprite';

interface SpriteSpec {
  url: string;
  width: number;   // 게임 가상 좌표계 폭
  height: number;  // 게임 가상 좌표계 높이
}

const MARIO_SPECS: Record<string, SpriteSpec> = {
  // 작은 마리오
  mario_idle: { url: '/sprites/mario/2x/mario_idle.png', width: 14, height: 20 },
  mario_walk1: { url: '/sprites/mario/2x/mario_walk1.png', width: 14, height: 21 },
  mario_walk2: { url: '/sprites/mario/2x/mario_walk2.png', width: 15, height: 20 },
  mario_jump: { url: '/sprites/mario/2x/mario_jump.png', width: 16, height: 21 },
  mario_die: { url: '/sprites/mario/2x/mario_die.png', width: 16, height: 21 },

  // 큰 마리오
  mario_big_idle: { url: '/sprites/mario/2x/mario_big_idle.png', width: 20, height: 36 },
  mario_big_walk1: { url: '/sprites/mario/2x/mario_big_walk1.png', width: 23, height: 36 },
  mario_big_walk2: { url: '/sprites/mario/2x/mario_big_walk2.png', width: 25, height: 36 },
  mario_big_jump: { url: '/sprites/mario/2x/mario_big_jump.png', width: 24, height: 36 },
};

class MarioSpriteManager {
  private images = new Map<string, HTMLImageElement>();
  private loaded = new Map<string, boolean>();

  constructor() {
    this.preloadAll();
  }

  private preloadAll(): void {
    if (typeof window === 'undefined') return;

    for (const [name, spec] of Object.entries(MARIO_SPECS)) {
      const img = new Image();
      img.src = spec.url;
      img.onload = () => {
        this.loaded.set(name, true);
      };
      img.onerror = () => {
        console.warn(`Failed to load Mario sprite: ${spec.url}`);
        this.loaded.set(name, false);
      };
      this.images.set(name, img);
    }
  }

  /**
   * 마리오 캐릭터를 지면과 중심축에 맞추어 깨짐 없이 렌더링
   * @param ctx Canvas 컨텍스트
   * @param name 스프라이트 이름
   * @param playerX 플레이어 물리 X
   * @param playerY 플레이어 물리 Y
   * @param playerWidth 플레이어 물리 폭 (14)
   * @param playerHeight 플레이어 물리 높이 (작은 마리오 16, 큰 마리오 32)
   * @param flipX 좌우 반전 여부
   */
  draw(
    ctx: CanvasRenderingContext2D,
    name: string,
    playerX: number,
    playerY: number,
    playerWidth: number,
    playerHeight: number,
    flipX: boolean,
  ): void {
    const spec = MARIO_SPECS[name];
    const img = this.images.get(name);
    const isReady = this.loaded.get(name) && img && img.complete && img.naturalWidth > 0;

    // 이미지가 아직 로드되지 않았으면 기존 ProceduralSprite로 부드럽게 대체
    if (!spec || !isReady || !img) {
      drawProceduralSprite(ctx, name, playerX - 1, playerY, flipX);
      return;
    }

    const spriteW = spec.width;
    const spriteH = spec.height;

    // 지면(발바닥) 기준 정렬: 발바닥이 player.pos.y + player.height 위치에 정확히 안착
    const groundY = playerY + playerHeight;
    const drawY = Math.round(groundY - spriteH);

    // X축 중심 정렬: 충돌 박스 중심과 스프라이트 중심 일치
    const centerX = playerX + playerWidth / 2;
    const drawX = Math.round(centerX - spriteW / 2);

    ctx.save();
    // 픽셀 아트 선명도 유지
    ctx.imageSmoothingEnabled = false;

    if (flipX) {
      ctx.translate(Math.round(centerX), drawY);
      ctx.scale(-1, 1);
      ctx.drawImage(img, -Math.round(spriteW / 2), 0, spriteW, spriteH);
    } else {
      ctx.drawImage(img, drawX, drawY, spriteW, spriteH);
    }

    ctx.restore();
  }
}

export const marioSpriteManager = new MarioSpriteManager();
